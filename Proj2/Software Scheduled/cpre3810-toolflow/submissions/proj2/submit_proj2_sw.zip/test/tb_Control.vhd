library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity tb_Control is
end tb_Control;

architecture behavior of tb_Control is

    -- DUT component
    component Control
        port(
            i_opcode     : in  std_logic_vector(6 downto 0);
            i_func3      : in  std_logic_vector(2 downto 0);
            i_func7      : in  std_logic_vector(6 downto 0);
            o_ALUControl : out std_logic_vector(3 downto 0);
            o_ImmType    : out std_logic_vector(1 downto 0);
            o_ALUSRC     : out std_logic;
            o_MemReg     : out std_logic;
            o_RegWr      : out std_logic;
            o_MemRd      : out std_logic;
            o_MemWr      : out std_logic;
            o_Branch     : out std_logic
        );
    end component;

    -- Signals
    signal i_opcode     : std_logic_vector(6 downto 0) := (others => '0');
    signal i_func3      : std_logic_vector(2 downto 0) := (others => '0');
    signal i_func7      : std_logic_vector(6 downto 0) := (others => '0');
    signal o_ALUControl : std_logic_vector(3 downto 0);
    signal o_ImmType    : std_logic_vector(1 downto 0);
    signal o_ALUSRC     : std_logic;
    signal o_MemReg     : std_logic;
    signal o_RegWr      : std_logic;
    signal o_MemRd      : std_logic;
    signal o_MemWr      : std_logic;
    signal o_Branch     : std_logic;

begin

    --------------------------------------------------------------------
    -- DUT instance
    --------------------------------------------------------------------
    uut: Control
        port map(
            i_opcode     => i_opcode,
            i_func3      => i_func3,
            i_func7      => i_func7,
            o_ALUControl => o_ALUControl,
            o_ImmType    => o_ImmType,
            o_ALUSRC     => o_ALUSRC,
            o_MemReg     => o_MemReg,
            o_RegWr      => o_RegWr,
            o_MemRd      => o_MemRd,
            o_MemWr      => o_MemWr,
            o_Branch     => o_Branch
        );

    --------------------------------------------------------------------
    -- Test sequence
    --------------------------------------------------------------------
    stim_proc: process
    begin
        -- ADD
        i_opcode <= "0110011"; i_func3 <= "000"; i_func7 <= "0000000";
        wait for 10 ns;

        -- SUB
        i_opcode <= "0110011"; i_func3 <= "000"; i_func7 <= "0100000";
        wait for 10 ns;

        -- AND
        i_opcode <= "0110011"; i_func3 <= "111"; i_func7 <= "0000000";
        wait for 10 ns;

        -- OR
        i_opcode <= "0110011"; i_func3 <= "110"; i_func7 <= "0000000";
        wait for 10 ns;

        -- XOR
        i_opcode <= "0110011"; i_func3 <= "100"; i_func7 <= "0000000";
        wait for 10 ns;

        -- SLT
        i_opcode <= "0110011"; i_func3 <= "010"; i_func7 <= "0000000";
        wait for 10 ns;

        -- ADDI
        i_opcode <= "0010011"; i_func3 <= "000"; i_func7 <= "0000000";
        wait for 10 ns;

        -- ANDI
        i_opcode <= "0010011"; i_func3 <= "111"; i_func7 <= "0000000";
        wait for 10 ns;

        -- ORI
        i_opcode <= "0010011"; i_func3 <= "110"; i_func7 <= "0000000";
        wait for 10 ns;

        -- XORI
        i_opcode <= "0010011"; i_func3 <= "100"; i_func7 <= "0000000";
        wait for 10 ns;

        wait;
    end process;

end behavior;
